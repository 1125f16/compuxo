var obj = require('./contact.json');

console.log(obj);