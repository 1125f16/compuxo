var list = [5,8,9,2,7,6,3,1,4];

function callback(list){
	// --- YourCode ---
}

function filter(list,callback){
	// --- YourCode ---
}

var filtered = filter(list, callback);
console.log(filtered);