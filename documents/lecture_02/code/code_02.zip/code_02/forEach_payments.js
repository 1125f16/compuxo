var payments = require('./payments_2005_to_2010.json');

function add(item){
	// -----------------------------
	//    YOUR CODE: write callback 
	// -----------------------------
}
payments.data.forEach(add);