# ---------------------------
#   Web Server + MySQL
#   Install: 
#       Flask-MySQL
# ---------------------------

# imports
from flask import Flask
from flaskext.mysql import MySQL

# web application
app = Flask(__name__)

# connect to db
mysql = MySQL()
app.config['MYSQL_DATABASE_USER']     = 'admin'
app.config['MYSQL_DATABASE_PASSWORD'] = 'parks1999'
app.config['MYSQL_DATABASE_DB']       = 'education'
app.config['MYSQL_DATABASE_HOST']     = 'abelmsql.caqbocwjs5xp.us-east-1.rds.amazonaws.com'
mysql.init_app(app)

@app.route('/')
def colleges():
    cursor = mysql.get_db().cursor()
    response = cursor.execute("SELECT * FROM Colleges")
    html = ''    
    if response > 0:
        colleges = cursor.fetchall()
        for college in colleges:
            html += college[1] + '<br/>'
        return html

# start server
if __name__ == '__main__':
    app.run(host='0.0.0.0',debug=True, port=3000)