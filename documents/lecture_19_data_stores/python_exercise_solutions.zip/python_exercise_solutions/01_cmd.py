# ---------------------------
#   Terminal + MySQL 
#   Install:
#       mysql-connector-python
# ---------------------------

import mysql.connector

cnx = mysql.connector.connect(user='admin', 
    password='parks1999',
    host='abelmsql.caqbocwjs5xp.us-east-1.rds.amazonaws.com',
    database='education',
    auth_plugin='mysql_native_password')

cursor = cnx.cursor()
query = ("SELECT * FROM Colleges")
cursor.execute(query)

# print all the first cell of all the rows
for row in cursor.fetchall():
    print(row)

cursor.close()
cnx.close()
