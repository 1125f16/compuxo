module.exports.collectionName = "onetwofive";
module.exports.region = "us-east-1";