# Supported Languages

| Code | Language |
| ---- | -------- |
| ar | Arabic |
| bg | Bulgarian |
| ca | Catalan |
| zh_cn | Chinese (Simplified) |
| zh_tw | Chinese (Traditional) |
| hr | Croatian |
| cs | Czech |
| da | Danish |
| nl | Dutch |
| en | English |
| en_gb | English (UK) |
| fa | Farsi |
| fil | Filipino |
| fi | Finnish |
| fr | French |
| de | German |
| el | Greek |
| iw | Hebrew |
| hi | Hindi |
| hu | Hungarian |
| id | Indonesian |
| it | Italian |
| ja | Japanese |
| ko | Korean |
| lv | Latvian |
| lt | Lithuanian |
| no | Norwegian (Bokmal) |
| pl | Polish |
| pt | Portuguese |
| pt_pt | Portuguese (Portugal) |
| ro | Romanian |
| ru | Russian |
| sr | Serbian |
| sk | Slovak |
| sl | Slovenian |
| es | Spanish |
| es_419 | Spanish (Latin America) |
| sv | Swedish |
| th | Thai |
| tr | Turkish |
| uk | Ukrainian |
| vi | Vietnamese |
