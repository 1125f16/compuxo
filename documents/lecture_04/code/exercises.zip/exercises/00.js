var boston = require('./00_boston.json');
console.log(boston.data[10]);